function type(n, t) {
    var str = document.getElementsByTagName('code')[n].innerHTML.toString();
    var i = 0;
    document.getElementsByTagName('code')[n].innerHTML = "";
    setTimeout(function() {
        var se = setInterval(function() {
            i++;
            document.getElementsByTagName("code")[n].innerHTML =
                str.slice(0, i) + "|";
            if (i == str.length) {
                clearInterval(se);
                document.getElementsByTagName("code")[n].innerHTML = str;
            }
        }, 10);
    }, t);
}
type(0, 0);
type(1, 200);
type(2, 400);
type(3, 400);
type(4, 600);
type(5, 400);