<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="icon" href="<?php echo e(asset('assets/images/logo/lnu_logo.png')); ?>" type="image/png" nonce="<?php echo e(csp_nonce()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app.scss'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>E-LNU-IDS</title>  
</head>
<body>
    <div class="wrapper">
        <div class="content-wrapper" id="app">
            <router-view></router-view>
        </div>
    </div>
    
</body>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</html><?php /**PATH C:\laragon\www\e-lnu-ids\resources\views/app.blade.php ENDPATH**/ ?>