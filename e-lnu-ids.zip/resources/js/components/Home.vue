<template>
    <div>
      <h1>Home</h1>
      <p>Welcome to the home page!</p>
    </div>
  </template>
  
  <script>
  export default {
    // Home page content and functionality can be added here
  };
  </script>
  
  <style scoped>
  /* Add your component-specific styles here */
  </style>
  